<?php
    $conn = mysqli_connect('localhost', 'root', '', 'public_library');
?>